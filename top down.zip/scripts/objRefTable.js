const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.EightDir,
		C3.Behaviors.bound,
		C3.Plugins.Keyboard,
		C3.Plugins.Tilemap,
		C3.Behaviors.solid,
		C3.Plugins.Text,
		C3.Plugins.Keyboard.Cnds.IsKeyDown,
		C3.Plugins.Sprite.Acts.SetAnim,
		C3.Plugins.Sprite.Acts.SetMirrored,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.System.Acts.ScrollToObject,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.System.Cnds.CompareVar,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.Text.Acts.SetVisible
	];
};
self.C3_JsPropNameTable = [
	{"8Direções": 0},
	{RestritoAoLayout: 0},
	{Sprite: 0},
	{Sprite2: 0},
	{Sprite3: 0},
	{Sprite4: 0},
	{Teclado: 0},
	{Sprite5: 0},
	{Sólido: 0},
	{Mosaico: 0},
	{Sprite6: 0},
	{Mosaico2: 0},
	{Sprite7: 0},
	{Sprite8: 0},
	{gramadodegramaabstratosemcosturafundopadraodeativosdejogodeervasdecamponaturalvistasuperior_: 0},
	{chave: 0},
	{Texto: 0},
	{tesouro: 0},
	{Texto2: 0},
	{par: 0},
	{Sprite9: 0},
	{direcao: 0}
];

self.InstanceType = {
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	Sprite4: class extends self.ISpriteInstance {},
	Teclado: class extends self.IInstance {},
	Sprite5: class extends self.ISpriteInstance {},
	Mosaico: class extends self.ITilemapInstance {},
	Sprite6: class extends self.ISpriteInstance {},
	Mosaico2: class extends self.ITilemapInstance {},
	Sprite7: class extends self.ISpriteInstance {},
	Sprite8: class extends self.ISpriteInstance {},
	gramadodegramaabstratosemcosturafundopadraodeativosdejogodeervasdecamponaturalvistasuperior_: class extends self.ISpriteInstance {},
	chave: class extends self.ISpriteInstance {},
	Texto: class extends self.ITextInstance {},
	tesouro: class extends self.ISpriteInstance {},
	Texto2: class extends self.ITextInstance {},
	par: class extends self.ITextInstance {},
	Sprite9: class extends self.ISpriteInstance {}
}